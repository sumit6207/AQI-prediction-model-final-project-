# Air-Quality-Index-Prediction-AICTE-Cycle-4
This repo is for training AICTE Cycle 4
